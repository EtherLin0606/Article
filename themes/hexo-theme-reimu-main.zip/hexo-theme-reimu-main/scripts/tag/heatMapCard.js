const { url_for } = require("hexo-util");

const i18n = {
  en: {
    no_articles: "No articles",
    words: "word(s)",
    total_articles: "$1 article(s), $2 word(s)",
  },
  ja: {
    no_articles: "記事がありません",
    words: "文字",
    total_articles: "$1 記事, $2 文字",
  },
  "zh-CN": {
    no_articles: "没有文章",
    words: "字",
    total_articles: "共 $1 篇文章, $2 字",
  },
  "zh-TW": {
    no_articles: "没有文章",
    words: "字",
    total_articles: "共 $1 篇文章, $2 字",
  },
  "pt-BR": {
    no_articles: "Sem artigos",
    words: "palavra(s)",
    total_articles: "$1 artigo(s), $2 palavra(s)",
  },
};

let asyncCss;
const js = hexo.extend.helper.get("js").bind(hexo);

/**
 * {% heatMapCard [levelStandard] %}
 */
hexo.extend.tag.register("heatMapCard", function (args) {
  if (!asyncCss) {
    asyncCss = hexo.extend.helper.get("asyncCss").bind(hexo);
  }
  let levelStandard = args.shift();
  if (!levelStandard) {
    levelStandard = "1000,5000,10000";
  }
  const articlesData = [];
  const wordCountFn = hexo.extend.helper.get("raw_wordcount");
  hexo.locals.invalidate();
  hexo.locals.get("posts").each((post) => {
    articlesData.push({
      title: post.title,
      date: post.date,
      updated: post.updated,
      wordcount: wordCountFn(post._content, post._id),
      url: url_for.call(hexo, post.path),
    });
  });

  return `<script>var REIMU_HEATMAP_CONFIG = {articleStats: ${JSON.stringify(
    articlesData
  )}, i18n: ${JSON.stringify(i18n)}, levelStandard: "${levelStandard}"};</script>${asyncCss("css/heat-map")}<div id="heatmap"></div>${js("js/heat_map")}`;
});
