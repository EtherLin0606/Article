hexo.extend.filter.register("stylus:renderer", (style) => {
  const themeConfig = hexo.theme.config;
  // google font families
  const familiesEnabled = themeConfig.font?.enable;
  const articleFamilies = (themeConfig.font?.article ?? [])
    .map((i) => `'${i}'`)
    .join(",");
  const codeFamilies = (themeConfig.font?.code ?? [])
    .map((i) => `'${i}'`)
    .join(",");
  // local font families
  const localArticleFamilies = (themeConfig.local_font?.article ?? [])
    .map((i) => `'${i}'`)
    .join(",");
  const localCodeFamilies = (themeConfig.local_font?.code ?? [])
    .map((i) => `'${i}'`)
    .join(",");
  // custom font families
  const customFamiliesEnabled = themeConfig.custom_font?.enable;
  const customArticleFamilies = (themeConfig.custom_font?.article ?? [])
    .map((i) => `'${i.name}'`)
    .join(",");
  const customCodeFamilies = (themeConfig.custom_font?.code ?? [])
    .map((i) => `'${i.name}'`)
    .join(",");
  // giscus iframe needs its own font stylesheet imports.
  const fontDisplay = "&display=swap";
  const fontStyles = ":400,400italic,700,700italic";
  const giscusGoogleFamilies = (
    themeConfig.font?.enable
      ? [
          ...(themeConfig.font?.article ?? []),
          ...(themeConfig.font?.code ?? []),
        ]
      : []
  )
    .filter((item) => item)
    .map((item) => item + fontStyles)
    .join("|");
  const giscusGoogleFontCss = giscusGoogleFamilies
    ? `https://fonts.googleapis.com/css?family=${giscusGoogleFamilies}${fontDisplay}`
    : "";
  const giscusCustomFontCss = (
    themeConfig.custom_font?.enable
      ? [
          ...(themeConfig.custom_font?.article ?? []).map((item) => item.css),
          ...(themeConfig.custom_font?.code ?? []).map((item) => item.css),
        ]
      : []
  ).filter((item, index, array) => item && array.indexOf(item) === index);

  // sponsor and article_copyright
  let postHasSponsor = false;
  let postHasCopyright = false;
  hexo.locals.get("posts").forEach((post) => {
    if (post.sponsor) {
      postHasSponsor = true;
    }
    if (post.copyright) {
      postHasCopyright = true;
    }
  });
  if (!postHasSponsor || !postHasCopyright) {
    hexo.locals.get("pages").forEach((page) => {
      if (page.sponsor) {
        postHasSponsor = true;
      }
      if (page.copyright) {
        postHasCopyright = true;
      }
    });
  }
  postHasSponsor = postHasSponsor || themeConfig.sponsor.enable;
  postHasCopyright = postHasCopyright || themeConfig.article_copyright.enable;

  // sidebar
  let postHasSidebar = false;
  hexo.locals.get("posts").forEach((post) => {
    if (post.sidebar) {
      postHasSidebar = true;
    }
  });

  // widgets
  const widgetConfig = themeConfig.widgets;
  const siteHasWidget = Array.isArray(widgetConfig) && widgetConfig.length > 0;

  // social keys
  const socialKeys = Object.keys(themeConfig.social || {});
  const shareKeys = themeConfig.share || [];

  // custom icons
  const footerIcon = themeConfig.footer.icon.url || "../images/taichi.png";
  const sponsorIcon = themeConfig.sponsor.icon.url || "../images/taichi.png";
  const topIcon = themeConfig.top.icon.url || "../images/taichi.png";

  // reimu_cursor
  // just for compatible
  const cursor = themeConfig.reimu_cursor;
  let cursorEnabled = true;
  let cursorDefault = "../images/cursor/reimu-cursor-default.png";
  let cursorPointer = "../images/cursor/reimu-cursor-pointer.png";
  let cursorText = "../images/cursor/reimu-cursor-text.png";
  if (typeof cursor === "boolean") {
    // old config
    cursorEnabled = cursor;
  } else if (typeof cursor === "object") {
    // new config
    cursorEnabled = cursor.enable;
    cursorDefault = cursor.cursor.default || cursorDefault;
    cursorPointer = cursor.cursor.pointer || cursorPointer;
    cursorText = cursor.cursor.text || cursorText;
  }
  // Internal theme token
  const internalTheme = themeConfig.internal_theme || {};
  const { light = {}, dark = {} } = internalTheme;

  // comments
  const hasValine =
    themeConfig.valine?.enable &&
    themeConfig.valine?.appId &&
    themeConfig.valine?.appKey;
  const hasWaline = themeConfig.waline?.enable && themeConfig.waline?.serverURL;
  const hasGitalk =
    themeConfig.gitalk?.enable &&
    themeConfig.gitalk?.clientID &&
    themeConfig.gitalk?.clientSecret;
  const hasGiscus = themeConfig.giscus?.enable;
  const hasUtterances =
    themeConfig.utterances?.enable && themeConfig.utterances?.repo;
  style
    .define(
      "article-families",
      articleFamilies.length && familiesEnabled ? articleFamilies + "," : "",
    )
    .define(
      "code-families",
      codeFamilies.length && familiesEnabled ? codeFamilies + "," : "",
    )
    .define(
      "local-article-families",
      localArticleFamilies.length
        ? localArticleFamilies
        : "-apple-system, 'PingFang SC', 'Microsoft YaHei', sans-serif",
    )
    .define(
      "local-code-families",
      localCodeFamilies.length
        ? localCodeFamilies
        : "Menlo, Monaco, Consolas, monospace",
    )
    .define(
      "custom-article-families",
      customArticleFamilies.length && customFamiliesEnabled
        ? customArticleFamilies + ","
        : "",
    )
    .define(
      "custom-code-families",
      customCodeFamilies.length && customFamiliesEnabled
        ? customCodeFamilies + ","
        : "",
    )
    .define("giscus-google-font-css", giscusGoogleFontCss)
    .define("giscus-custom-font-css-count", giscusCustomFontCss.length)
    .define("post-has-sponsor", postHasSponsor)
    .define("post-has-copyright", postHasCopyright)
    .define("post-has-sidebar", postHasSidebar)
    .define("site-has-widget", siteHasWidget)
    .define("site-has-share", shareKeys.length > 0)
    .define("social-keys", socialKeys)
    .define("share-keys", shareKeys)
    .define("footer-icon", footerIcon)
    .define("sponsor-icon", sponsorIcon)
    .define("top-icon", topIcon)
    .define("cursor-enabled", cursorEnabled)
    .define("cursor-default", cursorDefault)
    .define("cursor-pointer", cursorPointer)
    .define("cursor-text", cursorText)

    .define("light-red-0", light["--red-0"] || "#ff0000")
    .define("light-red-1", light["--red-1"] || "#ff5252")
    .define("light-red-2", light["--red-2"] || "#ff7c7c")
    .define("light-red-3", light["--red-3"] || "#ffafaf")
    .define("light-red-4", light["--red-4"] || "#ffd0d0")
    .define("light-red-5", light["--red-5"] || "#ffecec")
    .define("light-red-5-5", light["--red-5-5"] || "#fff3f3")
    .define("light-red-6", light["--red-6"] || "#fff7f7")
    .define(
      "light-color-red-6-shadow",
      light["--color-red-6-shadow"] || "rgba(255, 78, 78, 0.6)",
    )
    .define(
      "light-color-red-3-shadow",
      light["--color-red-3-shadow"] || "rgba(255, 78, 78, 0.3)",
    )
    .define("light-highlight-nav", light["--highlight-nav"] || "#f5f5f5")
    .define(
      "light-highlight-scrollbar",
      light["--highlight-scrollbar"] || "#d6d6d6",
    )
    .define(
      "light-highlight-background",
      light["--highlight-background"] || "#fdfdfd",
    )
    .define(
      "light-highlight-selection",
      light["--highlight-selection"] || "#e9e9e988",
    )
    .define(
      "light-highlight-foreground",
      light["--highlight-foreground"] || "#24292e",
    )
    .define(
      "light-highlight-comment",
      light["--highlight-comment"] || "#7d7d7d",
    )
    .define("light-highlight-red", light["--highlight-red"] || "#d73a49")
    .define("light-highlight-orange", light["--highlight-orange"] || "#e36209")
    .define("light-highlight-yellow", light["--highlight-yellow"] || "#cb911d")
    .define("light-highlight-green", light["--highlight-green"] || "#22863a")
    .define("light-highlight-aqua", light["--highlight-aqua"] || "#005cc5")
    .define("light-highlight-blue", light["--highlight-blue"] || "#032f62")
    .define("light-highlight-purple", light["--highlight-purple"] || "#6f42c1")
    .define(
      "light-highlight-deletion",
      light["--highlight-deletion"] || "#b31d28",
    )
    .define(
      "light-highlight-deletion-bg",
      light["--highlight-deletion-bg"] || "#ffeef0",
    )
    .define(
      "light-highlight-addition",
      light["--highlight-addition"] || "#22863a",
    )
    .define(
      "light-highlight-addition-bg",
      light["--highlight-addition-bg"] || "#f0fff4",
    )
    .define("dark-red-4", dark["--red-4"] || "rgba(255, 208, 208, 0.5)")
    .define("dark-red-5", dark["--red-5"] || "rgba(255,228,228,0.15)")
    .define("dark-red-5-5", dark["--red-5-5"] || "rgba(255,236,236,0.05)")
    .define("dark-red-6", dark["--red-6"] || "rgba(255, 243, 243, 0.2)")
    .define("dark-highlight-nav", dark["--highlight-nav"] || "#222830")
    .define(
      "dark-highlight-scrollbar",
      dark["--highlight-scrollbar"] || "#454d59",
    )
    .define(
      "dark-highlight-background",
      dark["--highlight-background"] || "#1e2027",
    )
    .define(
      "dark-highlight-selection",
      dark["--highlight-selection"] || "#51515155",
    )
    .define(
      "dark-highlight-foreground",
      dark["--highlight-foreground"] || "#c9d1d9",
    )
    .define("dark-highlight-comment", dark["--highlight-comment"] || "#8b949e")
    .define("dark-highlight-red", dark["--highlight-red"] || "#ff7b72")
    .define("dark-highlight-orange", dark["--highlight-orange"] || "#ffa657")
    .define("dark-highlight-yellow", dark["--highlight-yellow"] || "#ffcc66")
    .define("dark-highlight-green", dark["--highlight-green"] || "#7ee787")
    .define("dark-highlight-aqua", dark["--highlight-aqua"] || "#a5d6ff")
    .define("dark-highlight-blue", dark["--highlight-blue"] || "#79c0ff")
    .define("dark-highlight-purple", dark["--highlight-purple"] || "#d2a8ff")
    .define(
      "dark-highlight-deletion",
      dark["--highlight-deletion"] || "#ffa198",
    )
    .define(
      "dark-highlight-deletion-bg",
      dark["--highlight-deletion-bg"] || "#490202",
    )
    .define(
      "dark-highlight-addition",
      dark["--highlight-addition"] || "#7ee787",
    )
    .define(
      "dark-highlight-addition-bg",
      dark["--highlight-addition-bg"] || "#04260f",
    )

    .define("has-valine", hasValine)
    .define("has-waline", hasWaline)
    .define("has-gitalk", hasGitalk)
    .define("has-giscus", hasGiscus)
    .define("has-utterances", hasUtterances);

  giscusCustomFontCss.forEach((cssUrl, index) => {
    style.define(`giscus-custom-font-css-${index}`, cssUrl);
  });
});
